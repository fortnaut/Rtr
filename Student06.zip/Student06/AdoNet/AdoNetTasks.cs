﻿using DatabaseCourseExam.Data;
using Npgsql;
using NpgsqlTypes;

namespace DatabaseCourseExam.AdoNet;

public static class AdoNetTasks
{
    // Задание 9: проверка NULL через IsDBNull перед GetString/GetInt32.
    // Задание 12: фильтр по group_id — ввод ID, параметр NpgsqlParameter,
    // вывод только выбранной группы.
    public static async Task ShowStudentsAsync()
    {
        Console.Write("Введите ID группы: ");
        string? input = Console.ReadLine();

        if (!int.TryParse(input, out int groupId))
        {
            Console.WriteLine("Ошибка: некорректный ID группы.");
            return;
        }

        await using var connection = DatabaseConnection.Create();
        await connection.OpenAsync();

        const string sql = """
            SELECT s.id, s.first_name, s.last_name, s.age, g.name
            FROM students AS s
            JOIN student_groups AS g ON g.id = s.group_id
            WHERE s.group_id = @GroupId
            ORDER BY s.id;
            """;

        await using var command = new NpgsqlCommand(sql, connection);
        command.Parameters.Add("@GroupId", NpgsqlDbType.Integer).Value = groupId;

        await using var reader = await command.ExecuteReaderAsync();

        bool any = false;

        while (await reader.ReadAsync())
        {
            any = true;

            int id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
            string firstName = reader.IsDBNull(1)
                ? "(нет имени)"
                : reader.GetString(1);
            string lastName = reader.IsDBNull(2)
                ? "(нет фамилии)"
                : reader.GetString(2);
            int age = reader.IsDBNull(3) ? 0 : reader.GetInt32(3);
            string groupName = reader.IsDBNull(4)
                ? "(группа не указана)"
                : reader.GetString(4);

            Console.WriteLine(
                $"{id}. {firstName} {lastName}, " +
                $"возраст: {age}, группа: {groupName}");
        }

        if (!any)
        {
            Console.WriteLine("В выбранной группе студентов нет.");
        }
    }

    // Задание 1: проверка диапазона возраста 14–100 до обращения к БД;
    // сообщить число изменённых строк и обработать отсутствие студента.
    public static async Task UpdateStudentAgeAsync(
        int studentId,
        int newAge)
    {
        if (newAge < 14 || newAge > 100)
        {
            Console.WriteLine(
                "Ошибка: возраст должен быть в диапазоне от 14 до 100 лет.");
            return;
        }

        await using var connection = DatabaseConnection.Create();
        await connection.OpenAsync();

        const string sql = """
            UPDATE students
            SET age = @Age
            WHERE id = @StudentId;
            """;

        await using var command = new NpgsqlCommand(sql, connection);

        command.Parameters.Add("@Age", NpgsqlDbType.Integer).Value = newAge;
        command.Parameters.Add("@StudentId", NpgsqlDbType.Integer).Value =
            studentId;

        int affectedRows = await command.ExecuteNonQueryAsync();

        Console.WriteLine(
            affectedRows == 0
                ? "Студент не найден."
                : $"Изменено записей: {affectedRows}");
    }

    // Задание 10: до изменения доступных мест проверить существование
    // студента и отсутствие повторной записи; при любой ошибке
    // откатить транзакцию.
    public static async Task EnrollStudentAsync(
        int studentId,
        int courseId)
    {
        await using var connection = DatabaseConnection.Create();
        await connection.OpenAsync();

        await using var transaction = await connection.BeginTransactionAsync();

        try
        {
            const string checkStudentSql = """
                SELECT 1 FROM students WHERE id = @StudentId;
                """;

            await using (var checkStudent =
                new NpgsqlCommand(checkStudentSql, connection, transaction))
            {
                checkStudent.Parameters.Add(
                    "@StudentId", NpgsqlDbType.Integer).Value = studentId;

                object? exists = await checkStudent.ExecuteScalarAsync();

                if (exists is null)
                {
                    throw new InvalidOperationException("Студент не найден.");
                }
            }

            const string checkEnrollSql = """
                SELECT 1 FROM student_courses
                WHERE student_id = @StudentId
                  AND course_id = @CourseId;
                """;

            await using (var checkEnroll =
                new NpgsqlCommand(checkEnrollSql, connection, transaction))
            {
                checkEnroll.Parameters.Add(
                    "@StudentId", NpgsqlDbType.Integer).Value = studentId;
                checkEnroll.Parameters.Add(
                    "@CourseId", NpgsqlDbType.Integer).Value = courseId;

                object? already = await checkEnroll.ExecuteScalarAsync();

                if (already is not null)
                {
                    throw new InvalidOperationException(
                        "Студент уже записан на этот курс.");
                }
            }

            const string updateSql = """
                UPDATE courses
                SET available_places = available_places - 1
                WHERE id = @CourseId
                  AND available_places > 0
                RETURNING available_places;
                """;

            await using (var update =
                new NpgsqlCommand(updateSql, connection, transaction))
            {
                update.Parameters.Add(
                    "@CourseId", NpgsqlDbType.Integer).Value = courseId;

                object? result = await update.ExecuteScalarAsync();

                if (result is null)
                {
                    throw new InvalidOperationException(
                        "Курс не найден или свободных мест нет.");
                }
            }

            const string insertSql = """
                INSERT INTO student_courses (student_id, course_id)
                VALUES (@StudentId, @CourseId);
                """;

            await using (var insert =
                new NpgsqlCommand(insertSql, connection, transaction))
            {
                insert.Parameters.Add(
                    "@StudentId", NpgsqlDbType.Integer).Value = studentId;
                insert.Parameters.Add(
                    "@CourseId", NpgsqlDbType.Integer).Value = courseId;

                await insert.ExecuteNonQueryAsync();
            }

            await transaction.CommitAsync();
            Console.WriteLine("Студент записан на курс.");
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            Console.WriteLine($"Операция отменена: {ex.Message}");
        }
    }
}