﻿using System.Data;
using System.Linq;
using DatabaseCourseExam.Data;
using Npgsql;

namespace DatabaseCourseExam.AdoNet;

public static class DisconnectedTasks
{
    public static async Task<DataTable> LoadStudentsAsync()
    {
        var table = new DataTable("Students");

        await using var connection = DatabaseConnection.Create();
        await connection.OpenAsync();

        const string sql = """
            SELECT id, first_name, last_name, age, group_id
            FROM students
            ORDER BY id;
            """;

        await using var command = new NpgsqlCommand(sql, connection);
        using var adapter = new NpgsqlDataAdapter(command);

        adapter.Fill(table);
        table.PrimaryKey = new DataColumn[] { table.Columns["id"]! };

        return table;
    }

    public static void PrintTable(DataTable table)
    {
        foreach (DataRow row in table.Rows)
        {
            Console.WriteLine(
                $"{row["id"]}: {row["first_name"]} " +
                $"{row["last_name"]}, возраст {row["age"]}");
        }
    }

    // Задание 5: добавление новой строки в DataTable с проверкой возраста
    // и правильным RowState = Added.
    public static DataRow AddStudent(
        DataTable table,
        int id,
        string firstName,
        string lastName,
        int age,
        int groupId)
    {
        if (age < 16 || age > 100)
        {
            throw new ArgumentOutOfRangeException(
                nameof(age),
                "Возраст должен быть в диапазоне от 16 до 100.");
        }

        // NewRow создаёт строку вне таблицы (RowState = Detached).
        var row = table.NewRow();
        row["id"] = id;
        row["first_name"] = firstName;
        row["last_name"] = lastName;
        row["age"] = age;
        row["group_id"] = groupId;

        // Rows.Add переводит строку в RowState = Added.
        table.Rows.Add(row);

        Console.WriteLine($"Строка добавлена. RowState: {row.RowState}");

        return row;
    }

    // Задание 13: вывести RowState до и после изменения;
    // объяснить разницу Unchanged и Modified.
    public static void ChangeAgeInMemory(
        DataTable table,
        int studentId,
        int newAge)
    {
        DataRow? row = table.Rows.Find(studentId);

        if (row is null)
        {
            Console.WriteLine("Студент не найден в DataTable.");
            return;
        }

        // До изменения строка совпадает с БД → Unchanged.
        Console.WriteLine($"Состояние до изменения: {row.RowState}");

        row["age"] = newAge;

        // После изменения строка отличается от БД → Modified.
        Console.WriteLine($"Состояние после изменения: {row.RowState}");

        // Unchanged — Original == Current, строка совпадает с БД.
        // Modified  — Original хранит старое значение, Current — новое;
        //             на этом различии DataAdapter строит UPDATE.
        Console.WriteLine(
            "Unchanged: Original == Current, строка совпадает с БД. " +
            "Modified: Original — старое значение, Current — новое; " +
            "DataAdapter использует это для построения UPDATE.");
    }

    // Задание 8: после Update вывести количество сохранённых строк
    // и проверить, остались ли строки в состоянии Modified.
    public static int SaveChanges(DataTable table)
    {
        using var connection = DatabaseConnection.Create();
        connection.Open();

        const string sql = """
            UPDATE students
            SET age = @age
            WHERE id = @id;
            """;

        using var command = new NpgsqlCommand(sql, connection);
        command.UpdatedRowSource = UpdateRowSource.None;

        command.Parameters.Add(
            "@age", NpgsqlTypes.NpgsqlDbType.Integer, 4, "age");
        command.Parameters.Add(
            "@id", NpgsqlTypes.NpgsqlDbType.Integer, 4, "id");

        using var adapter = new NpgsqlDataAdapter();
        adapter.UpdateCommand = command;

        // Update возвращает число обработанных строк.
        int affectedRows = adapter.Update(table);

        Console.WriteLine($"Сохранено изменений: {affectedRows}");

        // Проверяем, остались ли строки в состоянии Modified.
        int stillModified = table.Rows
            .Cast<DataRow>()
            .Count(r => r.RowState == DataRowState.Modified);

        if (stillModified == 0)
        {
            Console.WriteLine(
                "Все изменения сохранены. Строк в состоянии Modified нет.");
        }
        else
        {
            Console.WriteLine(
                $"Внимание: осталось строк в состоянии Modified: {stillModified}");
        }

        return affectedRows;
    }
}