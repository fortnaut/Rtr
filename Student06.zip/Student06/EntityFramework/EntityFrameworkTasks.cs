﻿using DatabaseCourseExam.EntityFramework.Entities;
using Microsoft.EntityFrameworkCore;

namespace DatabaseCourseExam.EntityFramework;

public static class EntityFrameworkTasks
{
    // TODO (задание 11): Вывести студентов с названием группы; обеспечить загрузку связанной сущности без обращения к незагруженному свойству.
    public static async Task ShowStudentsAsync()
    {
        await using var context = SchoolDbContextFactory.Create();

        List<Student> students = await context.Students
            .Include(student => student.Group)
            .OrderBy(student => student.Id)
            .ToListAsync();
        // вывод студентов с названмем группы
        foreach (var student in students)
        {
            Console.WriteLine($"ID: {student.Id} | Студент: {student.FirstName} | {student.LastName} | Группа: {student.Group}");
        }
    }

    // TODO (задание 2): Добавить обработку DbUpdateException и объяснить, почему ограничение уникальности должно обеспечиваться БД.
    // TODO (задание 7): Проверить входные данные и отсутствие студента; сохранить изменения через SaveChangesAsync.
    public static async Task UpdateStudentAgeAsync(
        int studentId,
        int newAge)
    {
        await using var context = SchoolDbContextFactory.Create();

        // Проверка на отсутствие студента
        var student = await context.Students.FindAsync(studentId);
        if (student == null)
        {
            Console.WriteLine("Студент не найден");
            return;
        }

        student.Age = newAge;

        //Обработка DbUpdateException
        try
        {
            //Cохранить изменения через SaveChangesAsync
            int affectedRows = await context.SaveChangesAsync();
            Console.WriteLine($"Возраст изменен. Сохранено изменений: {affectedRows}");
        }
        catch (DbUpdateException ex)
        {
            Console.WriteLine($"Ошибка при сохранении в БД: {ex.InnerException?.Message ?? ex.Message}");
        }
    }

    // TODO (задание 6): Выбирать только нужные поля через Select и добавить вычисляемый признак «мест нет».
    public static async Task ShowCoursesAsync()
    {
        await using var context = SchoolDbContextFactory.Create();

        var courses = await context.Courses
            .OrderBy(course => course.Name)
            // Выбираем нужные поля через Select
            .Select(course => new
            {
                course.Name,
                course.Price,
                //вычисляем признак «мест нет»
                IsFull = course.AvailablePlaces <= 0
            })
            .ToListAsync();

        foreach (var course in courses)
        {
            string pracesText = course.IsFull
                ? "Мест нет"
                : "Есть места";
            Console.WriteLine($"{course.Name} | Цена: {course.Price:N2} | {pracesText}");
        }
    }
}