﻿using System;
using System.Threading.Tasks;
using System.Data;
using DatabaseCourseExam.AdoNet;
using DatabaseCourseExam.EntityFramework;
using DatabaseCourseExam.DapperTasks;

DataTable? studentsTable = null;

while (true)
{
    Console.WriteLine();
    Console.WriteLine("=== Зачёт по работе с БД ===");
    Console.WriteLine("1. Показать студентов");
    Console.WriteLine("2. Изменить возраст студента");
    Console.WriteLine("3. Записать студента на курс");
    Console.WriteLine("4. Загрузить студентов в DataTable");
    Console.WriteLine("5. Изменить возраст в DataTable");
    Console.WriteLine("6. Показать DataTable");
    Console.WriteLine("7. Сохранить изменения DataTable");
    Console.WriteLine("8. EF Core: показать студентов");
    Console.WriteLine("9. EF Core: изменить возраст студента");
    Console.WriteLine("10. EF Core: показать курсы");
    Console.WriteLine("11. Dapper: показать студентов");
    Console.WriteLine("12. Dapper: изменить возраст");
    Console.WriteLine("13. Dapper: показать курсы");
    Console.WriteLine("14. Dapper: записать студента на курс");
    Console.WriteLine("15. Показать студентов (ADO.NET, EF Core и Dapper)");
    Console.WriteLine("0. Выход");
    Console.Write("Выберите действие: ");

    string? choice = Console.ReadLine();

    try
    {
        switch (choice)
        {
            // ---------- ADO.NET ----------
            case "1":
                await AdoNetTasks.ShowStudentsAsync();
                break;

            case "2":
                Console.Write("ID студента: ");
                int id = int.Parse(Console.ReadLine()!);
                Console.Write("Новый возраст: ");
                int age = int.Parse(Console.ReadLine()!);
                await AdoNetTasks.UpdateStudentAgeAsync(id, age);
                break;

            case "3":
                Console.Write("ID студента: ");
                int sid = int.Parse(Console.ReadLine()!);
                Console.Write("ID курса: ");
                int cid = int.Parse(Console.ReadLine()!);
                await AdoNetTasks.EnrollStudentAsync(sid, cid);
                break;

            // ---------- DataTable ----------
            case "4":
                studentsTable = await DisconnectedTasks.LoadStudentsAsync();
                Console.WriteLine("DataTable загружен.");
                break;

            case "5":
                if (studentsTable is null)
                {
                    Console.WriteLine("Сначала загрузите DataTable (пункт 4).");
                    break;
                }
                Console.Write("ID студента: ");
                int did = int.Parse(Console.ReadLine()!);
                Console.Write("Новый возраст: ");
                int dage = int.Parse(Console.ReadLine()!);
                DisconnectedTasks.ChangeAgeInMemory(studentsTable, did, dage);
                break;

            case "6":
                if (studentsTable is null)
                {
                    Console.WriteLine("Сначала загрузите DataTable (пункт 4).");
                    break;
                }
                DisconnectedTasks.PrintTable(studentsTable);
                break;

            case "7":
                if (studentsTable is null)
                {
                    Console.WriteLine("Сначала загрузите DataTable (пункт 4).");
                    break;
                }
                DisconnectedTasks.SaveChanges(studentsTable);
                break;

            // ---------- EF Core ----------
            case "8":
                await EntityFrameworkTasks.ShowStudentsAsync();
                break;

            case "9":
                Console.Write("ID студента: ");
                int eid = int.Parse(Console.ReadLine()!);
                Console.Write("Новый возраст: ");
                int eage = int.Parse(Console.ReadLine()!);
                await EntityFrameworkTasks.UpdateStudentAgeAsync(eid, eage);
                break;

            case "10":
                await EntityFrameworkTasks.ShowCoursesAsync();
                break;

            // ---------- Dapper ----------
            case "11":
                await DapperStudentTasks.ShowStudentsAsync();
                break;

            case "12":
                Console.Write("ID студента: ");
                int daid = int.Parse(Console.ReadLine()!);
                Console.Write("Новый возраст: ");
                int daage = int.Parse(Console.ReadLine()!);
                await DapperStudentTasks.UpdateStudentAgeAsync(daid, daage);
                break;

            case "13":
                await DapperStudentTasks.ShowCoursesAsync();
                break;

            case "14":
                Console.Write("ID студента: ");
                int dsid = int.Parse(Console.ReadLine()!);
                Console.Write("ID курса: ");
                int dcid = int.Parse(Console.ReadLine()!);
                await DapperStudentTasks.EnrollStudentAsync(dsid, dcid);
                break;

            // ---------- Сравнение всех трёх ----------
            case "15":
                Console.WriteLine("\n >> Вывод через ADO.NET <<");
                await AdoNetTasks.ShowStudentsAsync();

                Console.WriteLine("\n >> Вывод через EF Core <<");
                await EntityFrameworkTasks.ShowStudentsAsync();

                Console.WriteLine("\n >> Вывод через Dapper <<");
                await DapperStudentTasks.ShowStudentsAsync();
                break;

            case "0":
                Console.WriteLine("Выход");
                return;

            default:
                Console.WriteLine("Неверный пункт меню. Попробуйте снова.");
                break;
        }
    }
    catch (FormatException)
    {
        Console.WriteLine("Введите целое число.");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Ошибка: {ex.Message}");
    }
}